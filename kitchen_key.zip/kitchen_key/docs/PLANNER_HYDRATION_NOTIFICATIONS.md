# Planner, Hydration & Notifications — Design & Implementation Guide

How the **Meal Planner**, **Hydration**, and **Notifications** features should work and how to build them. Target architecture: **data synced to the Django backend** with **server-driven push (FCM)** plus **on-device local notifications** for time-based reminders and offline fallback.

> Status today: all three are UI shells only.
> - `lib/features/meal_plan/meal_planner_screen.dart` — recipes hardcoded from `MockData`, "Add recipe"/"auto-generate" do nothing, single static week, no persistence.
> - `lib/features/hydration/hydration_screen.dart` — in-memory glass counter, decorative reminder switches, resets on app close.
> - Notifications — none (no `flutter_local_notifications`/FCM, dead bell icon, static Settings toggles).
> - Backend exposes **recipe endpoints only** (`backend/recipes/data_store.py`) with **no auth / user-data**.

---

## 1. Architecture overview

```
┌──────────────────────────────┐     HTTPS + JWT      ┌───────────────────────────────┐
│  Flutter app (Riverpod)      │ ───────────────────► │  Django + DRF                  │
│                              │                      │                               │
│  Auth (JWT in secure store)  │ ◄─── JSON ────────── │  users / auth (SimpleJWT)      │
│  MealPlan / Hydration repos  │                      │  mealplan, hydration, prefs    │
│  NotificationService         │                      │  device tokens                 │
│  (flutter_local_notifications│                      │  scheduler (Celery beat)       │
│   + firebase_messaging)      │                      └───────────────┬───────────────┘
└──────────────┬───────────────┘                                      │ sends push
               │  receives push                                       ▼
               └───────────────────────  Firebase Cloud Messaging  ◄──┘
```

Everything here is **per-user**, so all three features depend on the **Auth prerequisite (§2)**. Until auth exists, they can run **device-local** (shared_preferences) as an interim, then switch the repository implementation to the API with no UI change.

---

## 2. Prerequisite — Authentication (blocks Planner/Hydration sync)

User-scoped data needs login. Build this first.

**Backend**
- Add `djangorestframework-simplejwt`. Create a `users` app (or reuse Django's `User`).
- Endpoints:
  - `POST /api/v1/auth/register/` → create user.
  - `POST /api/v1/auth/token/` → `{access, refresh}`.
  - `POST /api/v1/auth/token/refresh/`.
  - `GET /api/v1/auth/me/` → current profile.
- Scope every user-data view by `request.user` and set `permission_classes = [IsAuthenticated]`.

**Flutter**
- Wire the existing `login_screen.dart` / `register_screen.dart` to call the API.
- Store tokens with `flutter_secure_storage`.
- Extend `lib/core/network/api_client.dart` with an interceptor that:
  - attaches `Authorization: Bearer <access>`,
  - on `401`, calls token refresh once and retries; on failure routes to `/login`.

---

## 3. Meal Planner

### 3.1 How it works (UX)
- Weekly calendar with **real dates** and **week navigation** (prev/next week).
- Each day has slots: **Breakfast, Lunch, Dinner, Snack**.
- Tap an empty slot → **recipe picker** (reuses the catalog search) → pick → recipe is assigned to that day+slot.
- **Per-day nutrition totals** (calories + protein/carbs/fat) and a **weekly summary**, computed from assigned recipes.
- **Auto-generate**: fills the whole week from the catalog, respecting the user's diet preferences.
- **Generate shopping list**: aggregates the ingredients of every assigned recipe in the week → merges duplicates → groups by aisle → opens the existing `ShoppingListScreen`.
- Per-entry **servings** adjust (optional), **copy week**, **clear week**.

### 3.2 Backend
**Model**
```python
class MealPlanEntry(models.Model):
    user      = FK(User)
    date      = DateField()
    slot      = CharField(choices=["Breakfast","Lunch","Dinner","Snack"])
    recipe_id = IntegerField()      # id from recipes/data_store.py
    servings  = IntegerField(default=0)  # 0 = use recipe default
    class Meta: unique_together = ("user","date","slot")
```
**Endpoints**
| Method | Path | Purpose |
|---|---|---|
| GET | `/api/v1/mealplan/?week=YYYY-MM-DD` | All entries for that week (Mon–Sun) |
| PUT | `/api/v1/mealplan/` | Upsert one entry `{date, slot, recipe_id, servings}` |
| DELETE | `/api/v1/mealplan/<id>/` | Remove an entry |
| POST | `/api/v1/mealplan/auto/` | Auto-generate the week `{week, diet?}` |
| GET | `/api/v1/mealplan/shopping-list/?week=` | Merged ingredient list grouped by aisle |

- Resolve recipe details/ingredients server-side via `store.get(recipe_id)` (in `backend/recipes/data_store.py`) so the client doesn't have to fetch each recipe.
- Shopping-list endpoint: collect `ingredients` from each entry's recipe, normalize names, sum quantities where units match, attach `aisle`, return grouped.

### 3.3 Flutter
- Models: `MealPlanEntry`, `MealPlan` (with `fromJson`) under `lib/data/models/`.
- `MealPlanRepository` + providers in `lib/data/repositories/`:
  - `weekPlanProvider(weekStart)` → `FutureProvider.family`.
  - assign/remove/auto via a `MealPlanNotifier`, then `ref.invalidate(weekPlanProvider(week))`.
- In `meal_planner_screen.dart`:
  - replace the hardcoded `_plan` map with the week provider,
  - wire `onAdd` to a recipe-picker sheet built on `recipeListProvider` (search), reusing `RecipeListCard`,
  - wire the **auto-generate** button and the **Generate shopping list** button (already routes to `/shopping`) to populate `shoppingListProvider` from the API response.
- **Nutrition totals** reuse `Recipe.nutrition`.
- **Note:** the shopping-list grouping needs an `aisle` per ingredient. `RecipeIngredient` in `lib/data/models/recipe.dart` currently drops `aisle` — add it (the backend detail already provides it).

---

## 4. Hydration

### 4.1 How it works (UX)
- Daily **goal** (default 8 glasses / 2 L), configurable.
- Tap to **log / remove** a glass; animated **progress ring**.
- **Midnight rollover**: a new day resets the counter and archives the previous day.
- **7-day history** bar chart (`fl_chart`).
- **Reminder settings**: enabled, interval (e.g. every 2 h), quiet hours (e.g. 10 pm–7 am) — these drive notifications (§5).

### 4.2 Backend
**Models**
```python
class HydrationLog(models.Model):
    user, date = FK(User), DateField()
    glasses    = IntegerField(default=0)
    class Meta: unique_together = ("user","date")

class HydrationSettings(models.Model):
    user            = OneToOne(User)
    goal_glasses    = IntegerField(default=8)
    reminder_enabled= BooleanField(default=True)
    interval_hours  = IntegerField(default=2)
    quiet_start     = TimeField(default="22:00")
    quiet_end       = TimeField(default="07:00")
    timezone        = CharField(default="Asia/Karachi")
```
**Endpoints**
| Method | Path | Purpose |
|---|---|---|
| GET | `/api/v1/hydration/today/` | Today's glasses + goal |
| POST | `/api/v1/hydration/log/` | Increment or set today's glasses |
| GET | `/api/v1/hydration/history/?days=7` | Per-day totals for the chart |
| GET / PUT | `/api/v1/hydration/settings/` | Read / update goal + reminder config |

### 4.3 Flutter
- `HydrationRepository` + providers: `hydrationTodayProvider`, `hydrationHistoryProvider`, `hydrationSettingsProvider`.
- Upgrade `HydrationNotifier` (in `hydration_screen.dart`) to read/write the API and roll over by date.
- Saving settings → (re)schedule local reminders and PUT settings so the **server scheduler** also has them (§5).

---

## 5. Notifications

This is a **hybrid** — be deliberate about which path delivers what.

### 5a. On-device scheduled reminders — `flutter_local_notifications` (+ `timezone`)
Best for **time-based reminders**: hydration every N hours within waking/quiet hours, "Time to cook dinner: *<recipe>*" at meal times for today's plan, and cooking-timer-finished. These are **exact, offline, and need no server round-trip**.
- `NotificationService` initialised in `main()`:
  - init `timezone`, create channels (**Reminders / Planner / Cooking**),
  - request Android 13+ `POST_NOTIFICATIONS` + exact-alarm permission,
  - schedule **daily-repeating** notifications with `zonedSchedule` at the times computed from interval + quiet hours,
  - **cancel + reschedule** whenever settings change,
  - tap → deep-link via `go_router` (e.g. `/hydration`).

### 5b. Server-driven push — Firebase Cloud Messaging via Django
Best for **events the server originates**: new recipe matching prefs, weekly digest, a shared meal plan — and as the cloud path for reminders.
- Django stores `DeviceToken(user, fcm_token)`.
- A scheduler (**Celery beat** preferred; `django-crontab` or a cron'd management command also work) evaluates each user's settings on **their timezone**, respects quiet hours, and sends FCM via `fcm-django` / `pyfcm`.
- App receives with `firebase_messaging`: background handler shows a tray notification; foreground re-renders it through `flutter_local_notifications`.

### 5c. Recommendation (important)
Use **local notifications for time-based reminders** (hydration/meal/timer) and **FCM for server-initiated events** (new recipes, digests, shares). Pure server-push reminders require the device reachable and careful per-user timezone handling on the server — fine as a complement, but local scheduling is the reliable default for "remind me every 2 hours."

### 5d. Backend models / endpoints
| Model | Endpoint |
|---|---|
| `DeviceToken(user, fcm_token, platform)` | `POST /api/v1/devices/` register · `DELETE /api/v1/devices/<id>/` |
| `NotificationPref(user, recommendations, meal_reminders, hydration, digest)` | `GET / PUT /api/v1/notifications/prefs/` |
| `Notification(user, title, body, type, read, created)` *(optional inbox)* | `GET /api/v1/notifications/` |

### 5e. Flutter wiring
- Add `firebase_core`, `firebase_messaging`, `flutter_local_notifications`, `timezone`.
- `NotificationService` + `notificationPrefsProvider`.
- Wire the **dead bell icon** (home) → a **Notifications Center** screen (in-app inbox) on a new `/notifications` route.
- Make the **Settings toggles** persist to `/notifications/prefs/` and gate scheduling.

---

## 6. Packages & config checklist

**Flutter**
- `firebase_core`, `firebase_messaging`, `flutter_local_notifications`, `timezone`, `flutter_secure_storage`.
- `flutterfire configure` → `google-services.json`; AndroidManifest: notification receivers/permissions, a monochrome notification icon, `POST_NOTIFICATIONS`, exact-alarm permission.

**Django**
- `djangorestframework-simplejwt`, `fcm-django` (or `pyfcm`), `celery` + `redis` (or `django-crontab`).

---

## 7. Phased implementation order

1. **Auth (JWT)** — backend + Flutter Dio interceptor.
2. **Planner sync** — models, endpoints, recipe picker, nutrition totals, shopping-list generation.
3. **Hydration sync** — models, endpoints, history chart, settings.
4. **Local notifications** — hydration + meal reminders + timer.
5. **FCM** — device tokens + server scheduler + receive/deep-link.
6. **Notifications Center + Settings wiring**.

---

## 8. Testing / verification (for when implemented)

**Backend**
- DRF `APITestCase` per endpoint, asserting **user scoping** (a user only sees their own data) and auth (401 without token).
- `python manage.py check`.

**Flutter (end-to-end demo)**
- Log in → assign recipes across a week → kill & reopen the app → plan persists → **Generate shopping list** shows merged, aisle-grouped items.
- Log water → set reminder interval to ~2 minutes → confirm the notification fires in **foreground and background** → tapping opens Hydration.
- Toggle a Settings switch → verify scheduling/prefs update (and reminders stop when disabled).
- From Django, send a **test FCM** to the device token → confirm receipt + correct **deep-link**.

---

## 9. Notes & honest caveats
- **Auth is the gate** — Planner/Hydration can't truly sync without it. A device-local (`shared_preferences`) interim lets the UI work earlier; swap the repo to the API once auth lands, leaving widgets unchanged.
- **Recipe ids** come from `recipes.json` via `data_store.py`; the planner stores `recipe_id` and resolves details server-side — keep ids stable.
- **Timezones** matter for both quiet hours and the server scheduler; store and use the user's tz (`HydrationSettings.timezone`).
- **iOS** push needs an Apple Developer account + APNs key; Android/FCM is sufficient for the FYP demo.
