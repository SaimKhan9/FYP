import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/network/api_client.dart';
import '../../core/theme/app_spacing.dart';
import '../../data/models/recipe.dart';
import '../../data/repositories/recipe_repository.dart';
import 'empty_state.dart';
import 'skeletons.dart';

/// Infinite-scrolling recipe list. Fetches page 1 on build and loads more pages
/// as the user nears the bottom, so the whole catalog is reachable (not just the
/// first 40). Reused by Search and the meal-plan recipe picker.
class PagedRecipeList extends ConsumerStatefulWidget {
  final RecipeQuery query;
  final Widget Function(BuildContext context, Recipe recipe) itemBuilder;
  final EdgeInsetsGeometry padding;
  final Widget? emptyState;

  /// Optional external controller (e.g. a DraggableScrollableSheet's). When
  /// null the widget owns and disposes its own controller.
  final ScrollController? controller;

  const PagedRecipeList({
    super.key,
    required this.query,
    required this.itemBuilder,
    this.padding = const EdgeInsets.fromLTRB(
        AppSpacing.lg, 0, AppSpacing.lg, AppSpacing.xxl),
    this.emptyState,
    this.controller,
  });

  @override
  ConsumerState<PagedRecipeList> createState() => _PagedRecipeListState();
}

class _PagedRecipeListState extends ConsumerState<PagedRecipeList> {
  ScrollController? _owned;
  ScrollController get _scroll => widget.controller ?? _owned!;
  final List<Recipe> _items = [];
  int _page = 0;
  bool _hasMore = true;
  bool _loading = false;
  Object? _error;

  @override
  void initState() {
    super.initState();
    if (widget.controller == null) _owned = ScrollController();
    _scroll.addListener(_onScroll);
    _reset();
  }

  @override
  void didUpdateWidget(covariant PagedRecipeList old) {
    super.didUpdateWidget(old);
    if (old.query != widget.query) _reset();
  }

  @override
  void dispose() {
    _scroll.removeListener(_onScroll);
    _owned?.dispose(); // never dispose a controller we don't own
    super.dispose();
  }

  void _onScroll() {
    if (_scroll.position.pixels >= _scroll.position.maxScrollExtent - 400) {
      _loadMore();
    }
  }

  Future<void> _reset() async {
    setState(() {
      _items.clear();
      _page = 0;
      _hasMore = true;
      _loading = false;
      _error = null;
    });
    await _loadMore();
  }

  Future<void> _loadMore() async {
    if (_loading || !_hasMore) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    final nextPage = _page + 1;
    try {
      final res =
          await ref.read(recipeRepositoryProvider).getRecipesPage(widget.query, nextPage);
      if (!mounted) return;
      setState(() {
        _page = nextPage;
        _items.addAll(res.items);
        _hasMore = res.hasMore;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = e;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    // First page still loading: skeletons.
    if (_items.isEmpty && _loading) {
      return ListView.separated(
        padding: widget.padding,
        itemCount: 6,
        separatorBuilder: (_, _) => AppSpacing.vGapLg,
        itemBuilder: (_, _) => const RecipeCardSkeleton(),
      );
    }
    // First page failed with nothing to show.
    if (_items.isEmpty && _error != null) {
      return EmptyState(
        icon: Icons.cloud_off_rounded,
        title: 'Connection problem',
        message: describeApiError(_error!),
        actionLabel: 'Retry',
        onAction: _reset,
      );
    }
    if (_items.isEmpty) {
      return widget.emptyState ??
          const EmptyState(
            icon: Icons.search_off_rounded,
            title: 'No recipes found',
            message: 'Try a different keyword or filter.',
          );
    }

    return RefreshIndicator(
      onRefresh: _reset,
      child: ListView.separated(
        controller: _scroll,
        padding: widget.padding,
        itemCount: _items.length + 1, // trailing loader / end marker
        separatorBuilder: (_, i) => i < _items.length - 1 ? AppSpacing.vGapMd : AppSpacing.vGapLg,
        itemBuilder: (context, i) {
          if (i < _items.length) return widget.itemBuilder(context, _items[i]);
          return _Footer(
            loading: _loading,
            hasMore: _hasMore,
            error: _error,
            onRetry: _loadMore,
          );
        },
      ),
    );
  }
}

class _Footer extends StatelessWidget {
  final bool loading;
  final bool hasMore;
  final Object? error;
  final VoidCallback onRetry;
  const _Footer({required this.loading, required this.hasMore, required this.error, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    if (error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(AppSpacing.md),
          child: TextButton.icon(
            onPressed: onRetry,
            icon: const Icon(Icons.refresh_rounded),
            label: const Text('Tap to retry'),
          ),
        ),
      );
    }
    if (loading) {
      return const Padding(
        padding: EdgeInsets.all(AppSpacing.lg),
        child: Center(child: CircularProgressIndicator()),
      );
    }
    if (!hasMore) {
      return Padding(
        padding: const EdgeInsets.all(AppSpacing.lg),
        child: Center(
          child: Text('That\'s everything',
              style: Theme.of(context).textTheme.bodySmall),
        ),
      );
    }
    return const SizedBox(height: AppSpacing.xl);
  }
}
