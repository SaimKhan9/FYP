import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/network/api_client.dart';
import '../models/meal_entities.dart';
import '../models/meal_plan.dart';

class MealPlanRepository {
  final Dio _dio;
  MealPlanRepository(this._dio);

  Future<List<PlannedMeal>> getWeek(String weekStart) async {
    final res = await _dio.get('/mealplan/', queryParameters: {'week': weekStart});
    final entries = (res.data['entries'] as List? ?? const []);
    return entries.map((e) => PlannedMeal.fromJson((e as Map).cast<String, dynamic>())).toList();
  }

  Future<void> assign({
    required String date,
    required String slot,
    required int recipeId,
    int servings = 0,
  }) async {
    await _dio.put('/mealplan/', data: {
      'date': date,
      'slot': slot,
      'recipe_id': recipeId,
      'servings': servings,
    });
  }

  Future<void> remove(int entryId) => _dio.delete('/mealplan/$entryId/');

  Future<void> autoGenerate(String weekStart, {String diet = ''}) async {
    await _dio.post('/mealplan/auto/', data: {'week': weekStart, 'diet': diet});
  }

  Future<List<ShoppingItem>> shoppingList(String weekStart) async {
    final res = await _dio.get('/mealplan/shopping-list/', queryParameters: {'week': weekStart});
    final items = (res.data['items'] as List? ?? const []);
    return items.map((e) {
      final m = (e as Map).cast<String, dynamic>();
      final qty = m['quantity'];
      final unit = '${m['unit'] ?? ''}'.trim();
      final count = m['count'] ?? 1;
      final qtyLabel = [
        if (qty != null && '$qty'.isNotEmpty) '$qty',
        if (unit.isNotEmpty) unit,
        if ((count is int ? count : 1) > 1) '×$count',
      ].join(' ');
      return ShoppingItem(
        name: '${m['name']}',
        quantity: qtyLabel.trim(),
        aisle: '${m['aisle'] ?? 'Other'}',
      );
    }).toList();
  }
}

final mealPlanRepositoryProvider =
    Provider<MealPlanRepository>((ref) => MealPlanRepository(ref.watch(dioProvider)));

/// Entries for a given week start (ISO date of the Monday).
final weekPlanProvider =
    FutureProvider.autoDispose.family<List<PlannedMeal>, String>((ref, weekStart) {
  return ref.watch(mealPlanRepositoryProvider).getWeek(weekStart);
});
