import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../../core/network/api_client.dart';
import '../../core/network/token_store.dart';
import '../models/app_user.dart';

/// Wraps the dj-rest-auth endpoints and JWT storage.
class AuthRepository {
  final Dio _dio;
  AuthRepository(this._dio);

  Future<void> _storeFrom(Map data) async {
    final access = data['access'] ?? data['access_token'];
    final refresh = data['refresh'] ?? data['refresh_token'];
    if (access != null && refresh != null) {
      await TokenStore.instance.save(access: '$access', refresh: '$refresh');
    }
  }

  Future<AppUser> login(String email, String password) async {
    final res = await _dio.post('/auth/login/', data: {
      // dj-rest-auth accepts username or email; send both keys for flexibility.
      'username': email,
      'email': email,
      'password': password,
    });
    await _storeFrom(res.data as Map);
    return me();
  }

  Future<AppUser> register({
    required String username,
    required String email,
    required String password,
  }) async {
    final res = await _dio.post('/auth/registration/', data: {
      'username': username,
      'email': email,
      'password1': password,
      'password2': password,
    });
    await _storeFrom(res.data as Map);
    return me();
  }

  /// Google sign-in → exchange the id/access token for JWT at /auth/google/.
  Future<AppUser> googleLogin() async {
    final account = await GoogleSignIn.instance.authenticate();
    final auth = account.authentication;
    final res = await _dio.post('/auth/google/', data: {
      'id_token': auth.idToken,
    });
    await _storeFrom(res.data as Map);
    return me();
  }

  Future<AppUser> me() async {
    final res = await _dio.get('/profile/');
    return AppUser.fromJson((res.data as Map).cast<String, dynamic>());
  }

  Future<void> logout() async {
    try {
      await _dio.post('/auth/logout/');
    } catch (_) {
      // ignore network errors on logout
    }
    await TokenStore.instance.clear();
  }

  /// Change the signed-in user's password (requires the current one).
  Future<void> changePassword({
    required String oldPassword,
    required String newPassword,
  }) async {
    await _dio.post('/auth/password/change/', data: {
      'old_password': oldPassword,
      'new_password1': newPassword,
      'new_password2': newPassword,
    });
  }
}

final authRepositoryProvider =
    Provider<AuthRepository>((ref) => AuthRepository(ref.watch(dioProvider)));
