import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/network/api_client.dart';

class AppNotification {
  final int id;
  final String title;
  final String body;
  final String type;
  final String route;
  final bool read;
  final String created;

  const AppNotification({
    required this.id,
    required this.title,
    required this.body,
    required this.type,
    required this.route,
    required this.read,
    required this.created,
  });

  factory AppNotification.fromJson(Map<String, dynamic> j) => AppNotification(
        id: j['id'] as int,
        title: '${j['title'] ?? ''}',
        body: '${j['body'] ?? ''}',
        type: '${j['type'] ?? 'general'}',
        route: '${j['route'] ?? ''}',
        read: j['read'] == true,
        created: '${j['created'] ?? ''}',
      );
}

class InboxData {
  final int unread;
  final List<AppNotification> items;
  const InboxData(this.unread, this.items);
}

class NotificationRepository {
  final Dio _dio;
  NotificationRepository(this._dio);

  Future<InboxData> list() async {
    final res = await _dio.get('/notifications/');
    final results = (res.data['results'] as List? ?? const [])
        .map((e) => AppNotification.fromJson((e as Map).cast<String, dynamic>()))
        .toList();
    return InboxData(res.data['unread'] ?? 0, results);
  }

  Future<void> markRead(int id) => _dio.post('/notifications/$id/read/');

  Future<Map<String, dynamic>> getPrefs() async {
    final res = await _dio.get('/notifications/prefs/');
    return (res.data as Map).cast<String, dynamic>();
  }

  Future<Map<String, dynamic>> updatePrefs(Map<String, dynamic> patch) async {
    final res = await _dio.put('/notifications/prefs/', data: patch);
    return (res.data as Map).cast<String, dynamic>();
  }
}

final notificationRepositoryProvider =
    Provider<NotificationRepository>((ref) => NotificationRepository(ref.watch(dioProvider)));

final inboxProvider =
    FutureProvider.autoDispose<InboxData>((ref) => ref.watch(notificationRepositoryProvider).list());

final notificationPrefsProvider = FutureProvider.autoDispose<Map<String, dynamic>>(
    (ref) => ref.watch(notificationRepositoryProvider).getPrefs());
