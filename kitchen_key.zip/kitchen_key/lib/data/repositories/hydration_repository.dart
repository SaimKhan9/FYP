import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/network/api_client.dart';

class HydrationToday {
  final int glasses;
  final int goal;
  const HydrationToday(this.glasses, this.goal);
}

class HydrationRepository {
  final Dio _dio;
  HydrationRepository(this._dio);

  Future<HydrationToday> today() async {
    final res = await _dio.get('/hydration/today/');
    return HydrationToday(res.data['glasses'] ?? 0, res.data['goal'] ?? 8);
  }

  Future<int> log({int delta = 1, int? absolute}) async {
    final res = await _dio.post('/hydration/log/',
        data: absolute != null ? {'glasses': absolute} : {'delta': delta});
    return res.data['glasses'] ?? 0;
  }

  Future<List<MapEntry<String, int>>> history({int days = 7}) async {
    final res = await _dio.get('/hydration/history/', queryParameters: {'days': days});
    final series = (res.data['series'] as List? ?? const []);
    return series
        .map((e) => MapEntry('${e['date']}', (e['glasses'] ?? 0) as int))
        .toList();
  }

  Future<Map<String, dynamic>> getSettings() async {
    final res = await _dio.get('/hydration/settings/');
    return (res.data as Map).cast<String, dynamic>();
  }

  Future<Map<String, dynamic>> updateSettings(Map<String, dynamic> patch) async {
    final res = await _dio.put('/hydration/settings/', data: patch);
    return (res.data as Map).cast<String, dynamic>();
  }
}

final hydrationRepositoryProvider =
    Provider<HydrationRepository>((ref) => HydrationRepository(ref.watch(dioProvider)));

final hydrationTodayProvider =
    FutureProvider.autoDispose<HydrationToday>((ref) => ref.watch(hydrationRepositoryProvider).today());

final hydrationHistoryProvider = FutureProvider.autoDispose<List<MapEntry<String, int>>>(
    (ref) => ref.watch(hydrationRepositoryProvider).history());

final hydrationSettingsProvider = FutureProvider.autoDispose<Map<String, dynamic>>(
    (ref) => ref.watch(hydrationRepositoryProvider).getSettings());
