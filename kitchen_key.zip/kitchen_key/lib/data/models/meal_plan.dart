import 'recipe.dart';

/// One assigned meal in the weekly planner.
class PlannedMeal {
  final int id;
  final String date; // ISO yyyy-MM-dd
  final String slot; // Breakfast | Lunch | Dinner | Snack
  final int recipeId;
  final int servings;
  final Recipe? recipe; // light summary from the backend

  const PlannedMeal({
    required this.id,
    required this.date,
    required this.slot,
    required this.recipeId,
    required this.servings,
    this.recipe,
  });

  factory PlannedMeal.fromJson(Map<String, dynamic> j) {
    final r = j['recipe'];
    return PlannedMeal(
      id: j['id'] as int,
      date: '${j['date']}',
      slot: '${j['slot']}',
      recipeId: (j['recipe_id'] ?? 0) as int,
      servings: (j['servings'] ?? 0) as int,
      recipe: r is Map ? Recipe.fromJson(r.cast<String, dynamic>()) : null,
    );
  }
}
