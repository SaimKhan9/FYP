/// The signed-in user (from `/api/v1/auth/user/` or `/profile/`).
class AppUser {
  final String username;
  final String email;
  final List<String> dietaryPrefs;
  final List<String> allergies;
  final String skill;

  const AppUser({
    required this.username,
    required this.email,
    this.dietaryPrefs = const [],
    this.allergies = const [],
    this.skill = 'Beginner',
  });

  factory AppUser.fromJson(Map<String, dynamic> j) => AppUser(
        username: '${j['username'] ?? ''}',
        email: '${j['email'] ?? ''}',
        dietaryPrefs:
            (j['dietary_prefs'] as List?)?.map((e) => '$e').toList() ?? const [],
        allergies: (j['allergies'] as List?)?.map((e) => '$e').toList() ?? const [],
        skill: '${j['skill'] ?? 'Beginner'}',
      );
}
