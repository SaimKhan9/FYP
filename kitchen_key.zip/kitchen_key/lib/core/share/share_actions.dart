import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

import '../theme/app_spacing.dart';

const _whatsappGreen = Color(0xFF25D366);

/// Shows a share chooser: one-tap **WhatsApp** or the full system share sheet.
/// Used by the recipe detail and shopping list screens.
Future<void> shareContent(
  BuildContext context, {
  required String text,
  String? subject,
}) async {
  await showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    builder: (ctx) => SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            leading: const CircleAvatar(
              backgroundColor: _whatsappGreen,
              child: Icon(Icons.chat_rounded, color: Colors.white),
            ),
            title: const Text('Share to WhatsApp'),
            onTap: () async {
              Navigator.pop(ctx);
              await _shareToWhatsApp(context, text: text, subject: subject);
            },
          ),
          ListTile(
            leading: const CircleAvatar(
              child: Icon(Icons.ios_share_rounded),
            ),
            title: const Text('More apps…'),
            onTap: () async {
              Navigator.pop(ctx);
              await _systemShare(context, text: text, subject: subject);
            },
          ),
          AppSpacing.vGapSm,
        ],
      ),
    ),
  );
}

/// Opens WhatsApp directly with the text pre-filled. Falls back to wa.me (browser)
/// and then the system share sheet if WhatsApp isn't installed.
Future<void> _shareToWhatsApp(
  BuildContext context, {
  required String text,
  String? subject,
}) async {
  final encoded = Uri.encodeComponent(text);
  final appUri = Uri.parse('whatsapp://send?text=$encoded');
  final webUri = Uri.parse('https://wa.me/?text=$encoded');
  try {
    if (await canLaunchUrl(appUri)) {
      final ok = await launchUrl(appUri, mode: LaunchMode.externalApplication);
      if (ok) return;
    }
    final ok = await launchUrl(webUri, mode: LaunchMode.externalApplication);
    if (ok) return;
  } catch (_) {
    // fall through to the system sheet
  }
  if (context.mounted) await _systemShare(context, text: text, subject: subject);
}

Future<void> _systemShare(
  BuildContext context, {
  required String text,
  String? subject,
}) async {
  final box = context.findRenderObject() as RenderBox?;
  final origin = box != null ? box.localToGlobal(Offset.zero) & box.size : null;
  await SharePlus.instance.share(ShareParams(
    text: text,
    subject: subject,
    sharePositionOrigin: origin,
  ));
}
