import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../data/models/recipe.dart';
import '../../features/auth/auth_provider.dart';
import '../../features/auth/login_screen.dart';
import '../../features/auth/register_screen.dart';
import '../../features/generate/recipe_generation_screen.dart';
import '../../features/hydration/hydration_screen.dart';
import '../../features/notifications/notifications_center_screen.dart';
import '../../features/nutrition/nutrition_dashboard_screen.dart';
import '../../features/onboarding/onboarding_screen.dart';
import '../../features/onboarding/splash_screen.dart';
import '../../features/profile/change_password_screen.dart';
import '../../features/profile/profile_edit_screen.dart';
import '../../features/profile/settings_screen.dart';
import '../../features/recipe/recipe_detail_screen.dart';
import '../../features/shell/app_shell.dart';
import '../../features/shopping/shopping_list_screen.dart';

const _authRoutes = {'/splash', '/onboarding', '/login', '/register'};

/// The app router with an auth guard driven by [authControllerProvider].
final routerProvider = Provider<GoRouter>((ref) {
  final refresh = _AuthRefresh(ref);
  ref.onDispose(refresh.dispose);

  return GoRouter(
    initialLocation: '/splash',
    refreshListenable: refresh,
    redirect: (context, state) {
      final auth = ref.read(authControllerProvider).status;
      final loc = state.matchedLocation;
      if (auth == AuthStatus.unknown) return null; // wait on splash
      final onAuthRoute = _authRoutes.contains(loc);
      if (auth == AuthStatus.unauthenticated) {
        return onAuthRoute ? null : '/login';
      }
      // authenticated: keep them out of the auth/splash flow
      if (loc == '/splash' || loc == '/login' || loc == '/register') return '/home';
      return null;
    },
    routes: [
      GoRoute(path: '/splash', builder: (_, _) => const SplashScreen()),
      GoRoute(path: '/onboarding', builder: (_, _) => const OnboardingScreen()),
      GoRoute(path: '/login', builder: (_, _) => const LoginScreen()),
      GoRoute(path: '/register', builder: (_, _) => const RegisterScreen()),
      GoRoute(path: '/home', builder: (_, _) => const AppShell()),
      GoRoute(
        path: '/recipe',
        pageBuilder: (_, state) =>
            buildFadeThroughPage(RecipeDetailScreen(recipe: state.extra as Recipe), state),
      ),
      GoRoute(path: '/generate', builder: (_, _) => const RecipeGenerationScreen()),
      GoRoute(path: '/shopping', builder: (_, _) => const ShoppingListScreen()),
      GoRoute(path: '/hydration', builder: (_, _) => const HydrationScreen()),
      GoRoute(path: '/nutrition', builder: (_, _) => const NutritionDashboardScreen()),
      GoRoute(path: '/notifications', builder: (_, _) => const NotificationsCenterScreen()),
      GoRoute(path: '/profile/edit', builder: (_, _) => const ProfileEditScreen()),
      GoRoute(path: '/settings', builder: (_, _) => const SettingsScreen()),
      GoRoute(path: '/change-password', builder: (_, _) => const ChangePasswordScreen()),
    ],
  );
});

/// Bridges Riverpod auth changes to a [Listenable] for go_router.
class _AuthRefresh extends ChangeNotifier {
  _AuthRefresh(Ref ref) {
    ref.listen(authControllerProvider, (_, _) => notifyListeners());
  }
}

/// Shared fade+slide page transition helper for a polished feel.
Page<void> buildFadeThroughPage(Widget child, GoRouterState state) {
  return CustomTransitionPage(
    key: state.pageKey,
    child: child,
    transitionsBuilder: (context, animation, secondary, child) {
      return FadeTransition(
        opacity: animation,
        child: SlideTransition(
          position: Tween<Offset>(begin: const Offset(0, 0.03), end: Offset.zero)
              .animate(CurvedAnimation(parent: animation, curve: Curves.easeOut)),
          child: child,
        ),
      );
    },
  );
}
