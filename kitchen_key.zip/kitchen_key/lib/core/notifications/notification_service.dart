import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../network/api_client.dart';
import '../router/app_router.dart';

/// Background isolate handler — must be a top-level function.
@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  // "notification" messages are shown by the system tray automatically.
}

const _channel = AndroidNotificationChannel(
  'kk_reminders',
  'Reminders',
  description: 'Hydration and meal reminders',
  importance: Importance.high,
);

/// Handles FCM: permission, token registration to the backend, foreground
/// display via local notifications, and deep-linking on tap.
class NotificationService {
  final Ref _ref;
  NotificationService(this._ref);

  final _local = FlutterLocalNotificationsPlugin();
  bool _started = false;

  Future<void> init() async {
    if (_started) return;
    _started = true;

    final messaging = FirebaseMessaging.instance;
    await messaging.requestPermission();

    await _local.initialize(
      settings: const InitializationSettings(
        android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      ),
      onDidReceiveNotificationResponse: (resp) => _handleRoute(resp.payload),
    );
    await _local
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(_channel);

    FirebaseMessaging.onMessage.listen(_showForeground);
    FirebaseMessaging.onMessageOpenedApp.listen((m) => _handleRoute(m.data['route']));
    final initial = await messaging.getInitialMessage();
    if (initial != null) _handleRoute(initial.data['route']);

    messaging.onTokenRefresh.listen(_sendToken);
    await registerDevice(); // will 401 silently if not logged in yet
  }

  /// Registers this device's FCM token with the backend (needs the user logged in).
  Future<void> registerDevice() async {
    try {
      final token = await FirebaseMessaging.instance.getToken();
      if (token != null) await _sendToken(token);
    } catch (_) {}
  }

  Future<void> _sendToken(String token) async {
    try {
      await _ref.read(dioProvider).post('/devices/', data: {
        'registration_id': token,
        'type': 'android',
        'active': true,
      });
    } catch (_) {
      // not logged in yet, or offline — will retry after login / token refresh
    }
  }

  void _showForeground(RemoteMessage message) {
    final n = message.notification;
    if (n == null) return;
    _local.show(
      id: n.hashCode,
      title: n.title,
      body: n.body,
      notificationDetails: NotificationDetails(
        android: AndroidNotificationDetails(
          _channel.id,
          _channel.name,
          channelDescription: _channel.description,
          importance: Importance.high,
          priority: Priority.high,
          icon: '@mipmap/ic_launcher',
        ),
      ),
      payload: message.data['route'] as String?,
    );
  }

  void _handleRoute(String? route) {
    if (route == null || route.isEmpty) return;
    try {
      _ref.read(routerProvider).push(route);
    } catch (_) {}
  }
}

final notificationServiceProvider = Provider<NotificationService>((ref) => NotificationService(ref));
