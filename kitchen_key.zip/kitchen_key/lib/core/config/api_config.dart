import 'package:flutter/foundation.dart' show kIsWeb;

/// Backend connection settings.
///
/// The base URL is chosen automatically:
/// - Flutter **web/desktop on this PC**  →  http://127.0.0.1:8000 (direct, no tunnel)
/// - Everything else (**physical phone**) →  the ngrok https domain (any network)
///
/// This avoids the browser depending on ngrok (free ngrok URLs drop/change and a
/// dropped tunnel shows up in the browser as a generic XMLHttpRequest error).
///
/// Run the backend with:  python manage.py runserver 0.0.0.0:8000
class ApiConfig {
  ApiConfig._();

  /// Public tunnel used by the physical phone. Update when your ngrok URL changes.
  static const String ngrokUrl = 'https://nichole-nonrelativistic-tawna.ngrok-free.dev';

  /// Direct localhost used when running in a browser/desktop on the dev machine.
  static const String localUrl = 'http://127.0.0.1:8000';

  static String get baseUrl => kIsWeb ? localUrl : ngrokUrl;

  static const String apiPrefix = '/api/v1';

  static const Duration connectTimeout = Duration(seconds: 15);
  static const Duration receiveTimeout = Duration(seconds: 20);
}
