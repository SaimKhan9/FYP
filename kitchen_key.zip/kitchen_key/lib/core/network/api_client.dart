import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../config/api_config.dart';
import 'token_store.dart';

/// Configured Dio instance for talking to the Kitchen Key backend, with a JWT
/// auth interceptor (attaches the access token, refreshes once on 401).
Dio createDio() {
  final dio = Dio(BaseOptions(
    baseUrl: '${ApiConfig.baseUrl}${ApiConfig.apiPrefix}',
    connectTimeout: ApiConfig.connectTimeout,
    receiveTimeout: ApiConfig.receiveTimeout,
    contentType: Headers.jsonContentType,
    headers: {
      'Accept': 'application/json',
      // Only needed for the ngrok tunnel (phone). On web it's a pointless custom
      // header that triggers a CORS preflight against localhost — so skip it.
      if (!kIsWeb) 'ngrok-skip-browser-warning': 'true',
    },
  ));

  dio.interceptors.add(_AuthInterceptor(dio));

  assert(() {
    dio.interceptors.add(LogInterceptor(requestBody: true, responseBody: false));
    return true;
  }());
  return dio;
}

class _AuthInterceptor extends Interceptor {
  final Dio _dio;
  _AuthInterceptor(this._dio);

  bool _refreshing = false;

  bool _isAuthPath(String path) =>
      path.contains('/auth/login') ||
      path.contains('/auth/registration') ||
      path.contains('/auth/token') ||
      path.contains('/auth/google');

  @override
  Future<void> onRequest(RequestOptions options, RequestInterceptorHandler handler) async {
    if (!_isAuthPath(options.path)) {
      final token = await TokenStore.instance.accessToken;
      if (token != null) options.headers['Authorization'] = 'Bearer $token';
    }
    handler.next(options);
  }

  @override
  Future<void> onError(DioException err, ErrorInterceptorHandler handler) async {
    final status = err.response?.statusCode;
    final path = err.requestOptions.path;
    if (status == 401 && !_isAuthPath(path) && !_refreshing) {
      final refresh = await TokenStore.instance.refreshToken;
      if (refresh != null) {
        _refreshing = true;
        try {
          final res = await Dio(BaseOptions(baseUrl: _dio.options.baseUrl))
              .post('/auth/token/refresh/', data: {'refresh': refresh});
          final newAccess = res.data['access'] as String?;
          if (newAccess != null) {
            await TokenStore.instance.saveAccess(newAccess);
            final opts = err.requestOptions;
            opts.headers['Authorization'] = 'Bearer $newAccess';
            final retry = await _dio.fetch(opts);
            _refreshing = false;
            return handler.resolve(retry);
          }
        } catch (_) {
          // fall through to clearing tokens
        }
        _refreshing = false;
        await TokenStore.instance.clear();
      }
    }
    handler.next(err);
  }
}

final dioProvider = Provider<Dio>((ref) => createDio());

/// A user-friendly message for a Dio failure (used by error states in the UI).
String describeApiError(Object error) {
  if (error is DioException) {
    final data = error.response?.data;
    if (data is Map) {
      // Surface DRF field errors (e.g. {"email": ["already exists"]}).
      final first = data.values.firstWhere((v) => v != null, orElse: () => null);
      if (first is List && first.isNotEmpty) return '${first.first}';
      if (data['detail'] != null) return '${data['detail']}';
    }
    switch (error.type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.receiveTimeout:
      case DioExceptionType.sendTimeout:
        return 'The server took too long to respond.';
      case DioExceptionType.connectionError:
        return "Can't reach the server. Check it's running and the address in api_config.dart.";
      default:
        return 'Network error. Please try again.';
    }
  }
  return 'Something went wrong.';
}
