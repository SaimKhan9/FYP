import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Persists JWT access/refresh tokens in secure storage. Singleton so the Dio
/// interceptor and the auth controller share one source of truth.
class TokenStore {
  TokenStore._();
  static final TokenStore instance = TokenStore._();

  static const _access = 'kk_access';
  static const _refresh = 'kk_refresh';
  final _storage = const FlutterSecureStorage();

  String? _cachedAccess;

  Future<String?> get accessToken async => _cachedAccess ??= await _storage.read(key: _access);
  Future<String?> get refreshToken => _storage.read(key: _refresh);

  Future<void> save({required String access, required String refresh}) async {
    _cachedAccess = access;
    await _storage.write(key: _access, value: access);
    await _storage.write(key: _refresh, value: refresh);
  }

  Future<void> saveAccess(String access) async {
    _cachedAccess = access;
    await _storage.write(key: _access, value: access);
  }

  Future<void> clear() async {
    _cachedAccess = null;
    await _storage.delete(key: _access);
    await _storage.delete(key: _refresh);
  }

  Future<bool> get hasToken async => (await accessToken) != null;
}
