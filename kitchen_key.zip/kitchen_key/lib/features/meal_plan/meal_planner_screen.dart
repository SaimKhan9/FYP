import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../core/network/api_client.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../data/models/meal_plan.dart';
import '../../data/models/recipe.dart';
import '../../data/repositories/mealplan_repository.dart';
import '../../data/repositories/recipe_repository.dart';
import '../../shared/widgets/empty_state.dart';
import '../../shared/widgets/paged_recipe_list.dart';
import '../../shared/widgets/recipe_card.dart';
import '../shopping/shopping_list_screen.dart';

const _slots = ['Breakfast', 'Lunch', 'Dinner', 'Snack'];

class MealPlannerScreen extends ConsumerStatefulWidget {
  const MealPlannerScreen({super.key});

  @override
  ConsumerState<MealPlannerScreen> createState() => _MealPlannerScreenState();
}

class _MealPlannerScreenState extends ConsumerState<MealPlannerScreen> {
  late DateTime _weekStart;
  int _selectedDay = 0;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    _weekStart = DateTime(now.year, now.month, now.day).subtract(Duration(days: now.weekday - 1));
    _selectedDay = now.weekday - 1;
  }

  String _iso(DateTime d) => DateFormat('yyyy-MM-dd').format(d);
  DateTime get _selectedDate => _weekStart.add(Duration(days: _selectedDay));

  void _shiftWeek(int weeks) => setState(() => _weekStart = _weekStart.add(Duration(days: 7 * weeks)));

  Future<void> _run(Future<void> Function() action) async {
    setState(() => _busy = true);
    try {
      await action();
      ref.invalidate(weekPlanProvider(_iso(_weekStart)));
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(describeApiError(e))));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    final weekIso = _iso(_weekStart);
    final async = ref.watch(weekPlanProvider(weekIso));

    return Scaffold(
      body: SafeArea(
        child: RefreshIndicator(
          color: AppColors.primary,
          onRefresh: () async => ref.refresh(weekPlanProvider(weekIso).future),
          child: async.when(
            loading: () => const Center(child: CircularProgressIndicator(color: AppColors.primary)),
            error: (e, _) => ListView(children: [
              const SizedBox(height: 80),
              EmptyState(
                icon: Icons.cloud_off_rounded,
                title: 'Connection problem',
                message: describeApiError(e),
                actionLabel: 'Retry',
                onAction: () => ref.invalidate(weekPlanProvider(weekIso)),
              ),
            ]),
            data: (entries) => _content(context, text, entries),
          ),
        ),
      ),
    );
  }

  Widget _content(BuildContext context, TextTheme text, List<PlannedMeal> entries) {
    final dayIso = _iso(_selectedDate);
    final dayMeals = {for (final e in entries.where((e) => e.date == dayIso)) e.slot: e};
    final dayCalories = dayMeals.values.fold<int>(0, (s, e) => s + (e.recipe?.calories ?? 0));
    final protein = dayMeals.values.fold<int>(0, (s, e) => s + (e.recipe?.nutrition.proteinG ?? 0));
    final carbs = dayMeals.values.fold<int>(0, (s, e) => s + (e.recipe?.nutrition.carbsG ?? 0));
    final fat = dayMeals.values.fold<int>(0, (s, e) => s + (e.recipe?.nutrition.fatG ?? 0));

    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(AppSpacing.lg, AppSpacing.md, AppSpacing.lg, AppSpacing.sm),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Meal Planner', style: text.headlineMedium),
                      Text(
                        '${DateFormat('MMM d').format(_weekStart)} – '
                        '${DateFormat('MMM d').format(_weekStart.add(const Duration(days: 6)))}',
                        style: text.bodyMedium,
                      ),
                    ],
                  ),
                ),
                IconButton(onPressed: () => _shiftWeek(-1), icon: const Icon(Icons.chevron_left_rounded)),
                IconButton(onPressed: () => _shiftWeek(1), icon: const Icon(Icons.chevron_right_rounded)),
                Material(
                  color: AppColors.primarySurface,
                  shape: const CircleBorder(),
                  child: IconButton(
                    tooltip: 'Auto-generate week',
                    onPressed: _busy ? null : () => _run(() =>
                        ref.read(mealPlanRepositoryProvider).autoGenerate(_iso(_weekStart))),
                    icon: const Icon(Icons.auto_awesome_rounded, color: AppColors.primary),
                  ),
                ),
              ],
            ),
          ),
        ),

        // Day strip
        SliverToBoxAdapter(
          child: SizedBox(
            height: 76,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
              itemCount: 7,
              separatorBuilder: (_, _) => AppSpacing.hGapSm,
              itemBuilder: (context, i) {
                final d = _weekStart.add(Duration(days: i));
                final selected = i == _selectedDay;
                return GestureDetector(
                  onTap: () => setState(() => _selectedDay = i),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    width: 56,
                    decoration: BoxDecoration(
                      gradient: selected ? AppColors.brandGradient : null,
                      color: selected ? null : Theme.of(context).colorScheme.surface,
                      borderRadius: AppRadius.brMd,
                      border: Border.all(
                          color: selected ? Colors.transparent : Theme.of(context).colorScheme.outline),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(DateFormat('E').format(d).substring(0, 3),
                            style: text.labelSmall?.copyWith(
                                color: selected ? Colors.white70 : AppColors.textTertiary)),
                        const SizedBox(height: 4),
                        Text('${d.day}',
                            style: text.titleMedium?.copyWith(
                                color: selected ? Colors.white : AppColors.textPrimary)),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ),

        // Day totals
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.all(AppSpacing.lg),
            child: Container(
              padding: const EdgeInsets.all(AppSpacing.lg),
              decoration: BoxDecoration(gradient: AppColors.warmGradient, borderRadius: AppRadius.brLg),
              child: Row(
                children: [
                  const Icon(Icons.local_fire_department_rounded, color: Colors.white, size: 32),
                  AppSpacing.hGapMd,
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Today's total", style: text.bodySmall?.copyWith(color: Colors.white70)),
                      Text('$dayCalories kcal', style: text.headlineSmall?.copyWith(color: Colors.white)),
                    ],
                  ),
                  const Spacer(),
                  _MacroChip(label: 'P', value: '${protein}g'),
                  AppSpacing.hGapSm,
                  _MacroChip(label: 'C', value: '${carbs}g'),
                  AppSpacing.hGapSm,
                  _MacroChip(label: 'F', value: '${fat}g'),
                ],
              ),
            ),
          ),
        ),

        SliverList.list(children: [
          for (final slot in _slots)
            Padding(
              padding: const EdgeInsets.fromLTRB(AppSpacing.lg, 0, AppSpacing.lg, AppSpacing.md),
              child: _MealSlot(
                slot: slot,
                meal: dayMeals[slot],
                onAdd: () => _pickRecipe(slot),
                onRemove: dayMeals[slot] == null
                    ? null
                    : () => _run(() => ref.read(mealPlanRepositoryProvider).remove(dayMeals[slot]!.id)),
              ),
            ),
          Padding(
            padding: const EdgeInsets.all(AppSpacing.lg),
            child: OutlinedButton.icon(
              onPressed: _busy ? null : _generateShoppingList,
              icon: const Icon(Icons.shopping_cart_outlined),
              label: const Text('Generate shopping list'),
            ),
          ),
          const SizedBox(height: AppSpacing.xxl),
        ]),
      ],
    );
  }

  Future<void> _pickRecipe(String slot) async {
    final recipe = await showModalBottomSheet<Recipe>(
      context: context,
      isScrollControlled: true,
      builder: (_) => const _RecipePickerSheet(),
    );
    if (recipe == null) return;
    await _run(() => ref.read(mealPlanRepositoryProvider).assign(
          date: _iso(_selectedDate),
          slot: slot,
          recipeId: int.tryParse(recipe.id) ?? 0,
        ));
  }

  Future<void> _generateShoppingList() async {
    setState(() => _busy = true);
    try {
      final items = await ref.read(mealPlanRepositoryProvider).shoppingList(_iso(_weekStart));
      if (items.isEmpty) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Add some meals to the week first.')));
        }
        return;
      }
      ref.read(shoppingListProvider.notifier).setItems(items);
      if (mounted) context.push('/shopping');
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(describeApiError(e))));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }
}

class _MacroChip extends StatelessWidget {
  final String label;
  final String value;
  const _MacroChip({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.sm, vertical: 6),
      decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.22), borderRadius: AppRadius.brSm),
      child: Column(
        children: [
          Text(label, style: Theme.of(context).textTheme.labelSmall?.copyWith(color: Colors.white70)),
          Text(value, style: Theme.of(context).textTheme.labelMedium?.copyWith(color: Colors.white)),
        ],
      ),
    );
  }
}

class _MealSlot extends StatelessWidget {
  final String slot;
  final PlannedMeal? meal;
  final VoidCallback onAdd;
  final VoidCallback? onRemove;

  const _MealSlot({required this.slot, required this.meal, required this.onAdd, this.onRemove});

  IconData get _icon => switch (slot) {
        'Breakfast' => Icons.wb_sunny_rounded,
        'Lunch' => Icons.lunch_dining_rounded,
        'Snack' => Icons.cookie_rounded,
        _ => Icons.nightlight_round,
      };

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    final recipe = meal?.recipe;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          Icon(_icon, size: 18, color: AppColors.accent),
          AppSpacing.hGapSm,
          Text(slot, style: text.titleMedium),
        ]),
        AppSpacing.vGapSm,
        if (meal == null)
          GestureDetector(
            onTap: onAdd,
            child: Container(
              height: 72,
              decoration: BoxDecoration(
                borderRadius: AppRadius.brMd,
                border: Border.all(color: Theme.of(context).colorScheme.outline),
              ),
              child: const Center(
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.add_rounded, color: AppColors.primary),
                  SizedBox(width: 6),
                  Text('Add a recipe', style: TextStyle(color: AppColors.primary)),
                ]),
              ),
            ),
          )
        else
          Container(
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surface,
              borderRadius: AppRadius.brMd,
              border: Border.all(color: Theme.of(context).colorScheme.outline),
            ),
            padding: const EdgeInsets.all(AppSpacing.sm),
            child: Row(
              children: [
                ClipRRect(
                  borderRadius: AppRadius.brSm,
                  child: Image.network(recipe?.imageUrl ?? '',
                      width: 56, height: 56, fit: BoxFit.cover,
                      errorBuilder: (_, _, _) => Container(
                          width: 56, height: 56, color: AppColors.surfaceAlt,
                          child: const Icon(Icons.restaurant_rounded, color: AppColors.textTertiary))),
                ),
                AppSpacing.hGapMd,
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(recipe?.title ?? 'Recipe #${meal!.recipeId}',
                          maxLines: 1, overflow: TextOverflow.ellipsis, style: text.titleSmall),
                      Text('${recipe?.calories ?? 0} kcal · ${recipe?.totalMinutes ?? 0} min',
                          style: text.bodySmall),
                    ],
                  ),
                ),
                IconButton(onPressed: onRemove, icon: const Icon(Icons.close_rounded, size: 20)),
              ],
            ),
          ),
      ],
    );
  }
}

/// Bottom sheet to search the catalog and pick a recipe for a slot.
class _RecipePickerSheet extends ConsumerStatefulWidget {
  const _RecipePickerSheet();

  @override
  ConsumerState<_RecipePickerSheet> createState() => _RecipePickerSheetState();
}

class _RecipePickerSheetState extends ConsumerState<_RecipePickerSheet> {
  String _query = '';

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.8,
        maxChildSize: 0.95,
        builder: (context, scroll) => Column(
          children: [
            AppSpacing.vGapMd,
            Container(
              width: 40, height: 4,
              decoration: BoxDecoration(color: AppColors.border, borderRadius: AppRadius.brPill),
            ),
            Padding(
              padding: const EdgeInsets.all(AppSpacing.lg),
              child: TextField(
                autofocus: true,
                onChanged: (v) => setState(() => _query = v),
                decoration: const InputDecoration(
                    hintText: 'Search a recipe to add…', prefixIcon: Icon(Icons.search_rounded)),
              ),
            ),
            Expanded(
              child: PagedRecipeList(
                controller: scroll,
                query: RecipeQuery(search: _query),
                padding: const EdgeInsets.fromLTRB(AppSpacing.lg, 0, AppSpacing.lg, AppSpacing.xl),
                itemBuilder: (context, r) => RecipeListCard(
                  recipe: r,
                  onTap: () => Navigator.pop(context, r),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
