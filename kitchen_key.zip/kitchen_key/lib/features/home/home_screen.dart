import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/network/api_client.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../data/models/recipe.dart';
import '../../data/repositories/notification_repository.dart';
import '../../data/repositories/recipe_repository.dart';
import '../../shared/widgets/editorial_header.dart';
import '../../shared/widgets/empty_state.dart';
import '../../shared/widgets/recipe_card.dart';
import '../../shared/widgets/recipe_hero_image.dart';
import '../../shared/widgets/skeletons.dart';
import '../saved/saved_provider.dart';
import '../shell/app_shell.dart';

const _homeQuery = RecipeQuery(sort: 'name', limit: 20);

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  final _scroll = ScrollController();
  final List<Recipe> _items = [];
  int _page = 0;
  bool _hasMore = true;
  bool _loading = false;
  Object? _error;

  @override
  void initState() {
    super.initState();
    _scroll.addListener(_onScroll);
    _loadMore();
  }

  @override
  void dispose() {
    _scroll.removeListener(_onScroll);
    _scroll.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (_scroll.position.pixels >= _scroll.position.maxScrollExtent - 600) {
      _loadMore();
    }
  }

  Future<void> _refresh() async {
    setState(() {
      _items.clear();
      _page = 0;
      _hasMore = true;
      _loading = false;
      _error = null;
    });
    await _loadMore();
  }

  Future<void> _loadMore() async {
    if (_loading || !_hasMore) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    final next = _page + 1;
    try {
      final res = await ref.read(recipeRepositoryProvider).getRecipesPage(_homeQuery, next);
      if (!mounted) return;
      setState(() {
        _page = next;
        _items.addAll(res.items);
        _hasMore = res.hasMore;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = e;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: RefreshIndicator(
          color: AppColors.primary,
          onRefresh: _refresh,
          child: _body(context),
        ),
      ),
    );
  }

  Widget _body(BuildContext context) {
    if (_items.isEmpty && _loading) return const _HomeLoading();
    if (_items.isEmpty && _error != null) {
      return _HomeError(message: describeApiError(_error!), onRetry: _refresh);
    }
    if (_items.isEmpty) {
      return ListView(children: [
        const _Greeting(),
        const SizedBox(height: 80),
        const EmptyState(
          icon: Icons.ramen_dining_rounded,
          title: 'No recipes yet',
          message: 'Once your backend has recipes, they will appear here.',
        ),
      ]);
    }
    return _content(context, ref, _items);
  }

  Widget _content(BuildContext context, WidgetRef ref, List<Recipe> recipes) {
    final text = Theme.of(context).textTheme;
    final saved = ref.watch(savedRecipesProvider);

    void openRecipe(Recipe r) => context.push('/recipe', extra: r);
    void toggleSave(Recipe r) => ref.read(savedRecipesProvider.notifier).toggle(r);

    final featured = recipes.take(6).toList();
    final dayRecipe = recipes.first;

    return CustomScrollView(
      controller: _scroll,
      slivers: [
        const SliverToBoxAdapter(child: _Greeting()),

        // Recipe of the day
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(AppSpacing.lg, AppSpacing.xl, AppSpacing.lg, 0),
            child: GestureDetector(
              onTap: () => openRecipe(dayRecipe),
              child: ClipRRect(
                borderRadius: AppRadius.brLg,
                child: SizedBox(
                  height: 340,
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      RecipeHeroImage(url: dayRecipe.imageUrl, scrim: true),
                      Padding(
                        padding: const EdgeInsets.all(AppSpacing.xl),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.end,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                              decoration: BoxDecoration(
                                  color: AppColors.accent, borderRadius: AppRadius.brSm),
                              child: Text('RECIPE OF THE DAY',
                                  style: AppTypography.eyebrow(context, color: Colors.white)),
                            ),
                            AppSpacing.vGapMd,
                            Text(dayRecipe.title,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: text.displaySmall?.copyWith(color: Colors.white)),
                            const SizedBox(height: 6),
                            Text(
                              [
                                if (dayRecipe.cuisine.isNotEmpty) dayRecipe.cuisine,
                                if (dayRecipe.totalMinutes > 0) '${dayRecipe.totalMinutes} min',
                                if (dayRecipe.calories > 0) '${dayRecipe.calories} kcal',
                              ].join('  ·  '),
                              style: text.bodyMedium?.copyWith(color: Colors.white70),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ).animate().fadeIn(duration: 400.ms).slideY(begin: 0.05, end: 0),
          ),
        ),

        // Generate CTA
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(AppSpacing.lg, AppSpacing.xl, AppSpacing.lg, 0),
            child: GestureDetector(
              onTap: () => context.push('/generate'),
              child: Container(
                padding: const EdgeInsets.all(AppSpacing.lg),
                decoration: BoxDecoration(
                  gradient: AppColors.warmGradient,
                  borderRadius: AppRadius.brLg,
                  boxShadow: AppColors.cardShadow,
                ),
                child: Row(
                  children: [
                    const Icon(Icons.auto_awesome_rounded, color: Colors.white, size: 30),
                    AppSpacing.hGapMd,
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("What's in your fridge?",
                              style: text.titleMedium?.copyWith(color: Colors.white)),
                          Text('Suggest recipes from your ingredients',
                              style: text.bodySmall?.copyWith(color: Colors.white70)),
                        ],
                      ),
                    ),
                    const Icon(Icons.arrow_forward_rounded, color: Colors.white),
                  ],
                ),
              ),
            ),
          ),
        ),

        // Trending carousel
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(AppSpacing.lg, AppSpacing.xl, AppSpacing.lg, AppSpacing.md),
            child: const EditorialHeader(eyebrow: 'Fresh from the kitchen', title: 'Featured'),
          ),
        ),
        SliverToBoxAdapter(
          child: SizedBox(
            height: 340,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
              itemCount: featured.length,
              separatorBuilder: (_, _) => AppSpacing.hGapMd,
              itemBuilder: (context, i) {
                final r = featured[i];
                return FeaturedRecipeCard(
                  recipe: r,
                  isSaved: saved.containsKey(r.id),
                  onSaveTap: () => toggleSave(r),
                  onTap: () => openRecipe(r),
                );
              },
            ),
          ),
        ),

        // Recommended
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(AppSpacing.lg, AppSpacing.xl, AppSpacing.lg, AppSpacing.md),
            child: const EditorialHeader(eyebrow: 'Browse all', title: 'Recipes'),
          ),
        ),
        SliverList.separated(
          itemCount: recipes.length,
          separatorBuilder: (_, _) => AppSpacing.vGapMd,
          itemBuilder: (context, i) {
            final r = recipes[i];
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
              child: RecipeListCard(
                recipe: r,
                isSaved: saved.containsKey(r.id),
                onSaveTap: () => toggleSave(r),
                onTap: () => openRecipe(r),
              ),
            );
          },
        ),
        SliverToBoxAdapter(child: _BrowseFooter(
          loading: _loading,
          hasMore: _hasMore,
          error: _error,
          onRetry: _loadMore,
        )),
        const SliverToBoxAdapter(child: SizedBox(height: AppSpacing.xxl)),
      ],
    );
  }
}

class _BrowseFooter extends StatelessWidget {
  final bool loading;
  final bool hasMore;
  final Object? error;
  final VoidCallback onRetry;
  const _BrowseFooter(
      {required this.loading, required this.hasMore, required this.error, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    if (error != null) {
      return Padding(
        padding: const EdgeInsets.all(AppSpacing.md),
        child: Center(
          child: TextButton.icon(
            onPressed: onRetry,
            icon: const Icon(Icons.refresh_rounded),
            label: const Text('Tap to retry'),
          ),
        ),
      );
    }
    if (loading) {
      return const Padding(
        padding: EdgeInsets.all(AppSpacing.lg),
        child: Center(child: CircularProgressIndicator(color: AppColors.primary)),
      );
    }
    if (!hasMore) {
      return Padding(
        padding: const EdgeInsets.all(AppSpacing.lg),
        child: Center(
          child: Text("That's everything", style: Theme.of(context).textTheme.bodySmall),
        ),
      );
    }
    return const SizedBox(height: AppSpacing.xl);
  }
}

class _Greeting extends ConsumerWidget {
  const _Greeting();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final text = Theme.of(context).textTheme;
    final unread = ref.watch(inboxProvider).maybeWhen(data: (d) => d.unread, orElse: () => 0);
    return Padding(
      padding: const EdgeInsets.fromLTRB(AppSpacing.lg, AppSpacing.md, AppSpacing.lg, 0),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('GOOD MORNING',
                    style: AppTypography.eyebrow(context, color: AppColors.accent)),
                const SizedBox(height: 4),
                Text('Let’s cook something', style: text.headlineSmall),
              ],
            ),
          ),
          Stack(
            children: [
              Material(
                color: Theme.of(context).colorScheme.surface,
                shape: const CircleBorder(),
                child: IconButton(
                  onPressed: () => context.push('/notifications'),
                  icon: const Icon(Icons.notifications_none_rounded),
                ),
              ),
              if (unread > 0)
                Positioned(
                  right: 6, top: 6,
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: const BoxDecoration(color: AppColors.coral, shape: BoxShape.circle),
                    constraints: const BoxConstraints(minWidth: 16, minHeight: 16),
                    child: Text('$unread',
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.bold)),
                  ),
                ),
            ],
          ),
          AppSpacing.hGapSm,
          GestureDetector(
            onTap: () => ref.read(shellTabProvider.notifier).select(4),
            child: const CircleAvatar(
              radius: 22,
              backgroundColor: AppColors.primarySurface,
              child: Icon(Icons.person_rounded, color: AppColors.primary),
            ),
          ),
        ],
      ),
    );
  }
}

class _HomeLoading extends StatelessWidget {
  const _HomeLoading();

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(AppSpacing.lg),
      children: [
        const _Greeting(),
        AppSpacing.vGapLg,
        const SkeletonBox(height: 340, radius: AppRadius.brLg),
        AppSpacing.vGapLg,
        const SkeletonBox(height: 80, radius: AppRadius.brLg),
        AppSpacing.vGapLg,
        for (var i = 0; i < 4; i++) ...[
          const RecipeCardSkeleton(),
          AppSpacing.vGapLg,
        ],
      ],
    );
  }
}

class _HomeError extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;
  const _HomeError({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [
        const _Greeting(),
        const SizedBox(height: 60),
        EmptyState(
          icon: Icons.cloud_off_rounded,
          title: 'Connection problem',
          message: message,
          actionLabel: 'Retry',
          onAction: onRetry,
        ),
      ],
    );
  }
}
