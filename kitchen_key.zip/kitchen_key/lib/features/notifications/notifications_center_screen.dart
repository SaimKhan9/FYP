import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/network/api_client.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../data/repositories/notification_repository.dart';
import '../../shared/widgets/empty_state.dart';

class NotificationsCenterScreen extends ConsumerWidget {
  const NotificationsCenterScreen({super.key});

  IconData _icon(String type) => switch (type) {
        'hydration' => Icons.water_drop_rounded,
        'meal' => Icons.restaurant_rounded,
        'reminder' => Icons.notifications_active_rounded,
        'recommendation' => Icons.recommend_rounded,
        _ => Icons.notifications_rounded,
      };

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final text = Theme.of(context).textTheme;
    final async = ref.watch(inboxProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Notifications')),
      body: RefreshIndicator(
        color: AppColors.primary,
        onRefresh: () async => ref.refresh(inboxProvider.future),
        child: async.when(
          loading: () => const Center(child: CircularProgressIndicator(color: AppColors.primary)),
          error: (e, _) => ListView(children: [
            const SizedBox(height: 80),
            EmptyState(
              icon: Icons.cloud_off_rounded,
              title: 'Connection problem',
              message: describeApiError(e),
              actionLabel: 'Retry',
              onAction: () => ref.invalidate(inboxProvider),
            ),
          ]),
          data: (inbox) {
            if (inbox.items.isEmpty) {
              return ListView(children: const [
                SizedBox(height: 100),
                EmptyState(
                  icon: Icons.notifications_none_rounded,
                  title: 'No notifications yet',
                  message: 'Reminders and updates will appear here.',
                ),
              ]);
            }
            return ListView.separated(
              padding: const EdgeInsets.all(AppSpacing.lg),
              itemCount: inbox.items.length,
              separatorBuilder: (_, _) => AppSpacing.vGapSm,
              itemBuilder: (context, i) {
                final n = inbox.items[i];
                return Material(
                  color: n.read
                      ? Theme.of(context).colorScheme.surface
                      : AppColors.primarySurface,
                  borderRadius: AppRadius.brMd,
                  child: InkWell(
                    borderRadius: AppRadius.brMd,
                    onTap: () async {
                      await ref.read(notificationRepositoryProvider).markRead(n.id);
                      ref.invalidate(inboxProvider);
                      if (context.mounted && n.route.isNotEmpty) context.push(n.route);
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(AppSpacing.md),
                      child: Row(
                        children: [
                          Container(
                            width: 40, height: 40,
                            decoration: BoxDecoration(
                                color: AppColors.primary.withValues(alpha: 0.12),
                                borderRadius: AppRadius.brSm),
                            child: Icon(_icon(n.type), color: AppColors.primary, size: 20),
                          ),
                          AppSpacing.hGapMd,
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(n.title, style: text.titleSmall),
                                if (n.body.isNotEmpty) Text(n.body, style: text.bodySmall),
                              ],
                            ),
                          ),
                          if (!n.read)
                            const CircleAvatar(radius: 4, backgroundColor: AppColors.coral),
                        ],
                      ),
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
