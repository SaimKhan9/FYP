import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/network/api_client.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../shared/widgets/app_text_field.dart';
import 'auth_provider.dart';

class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});

  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  bool _obscure = true;
  bool _loading = false;

  @override
  void dispose() {
    _emailCtrl.dispose();
    _passwordCtrl.dispose();
    super.dispose();
  }

  Future<void> _run(Future<void> Function() action) async {
    if (_loading) return;
    setState(() => _loading = true);
    try {
      await action();
      // Router guard redirects to /home once authenticated.
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(describeApiError(e))));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _submit() {
    if (_formKey.currentState?.validate() ?? false) {
      _run(() => ref.read(authControllerProvider.notifier)
          .login(_emailCtrl.text.trim(), _passwordCtrl.text));
    }
  }

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(AppSpacing.xl),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                AppSpacing.vGapLg,
                Container(
                  width: 60,
                  height: 60,
                  decoration: const BoxDecoration(
                    gradient: AppColors.brandGradient,
                    borderRadius: AppRadius.brMd,
                  ),
                  child: const Icon(Icons.restaurant_menu_rounded, color: Colors.white, size: 32),
                ),
                AppSpacing.vGapXl,
                Text('Welcome back 👋', style: text.displaySmall ?? text.headlineMedium),
                const SizedBox(height: 6),
                Text('Sign in to continue cooking with Kitchen Key', style: text.bodyMedium),
                AppSpacing.vGapXxl,
                AppTextField(
                  label: 'Email or username',
                  hint: 'you@example.com',
                  icon: Icons.mail_outline_rounded,
                  keyboardType: TextInputType.emailAddress,
                  controller: _emailCtrl,
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'Required' : null,
                ),
                AppSpacing.vGapLg,
                AppTextField(
                  label: 'Password',
                  hint: 'Enter your password',
                  icon: Icons.lock_outline_rounded,
                  obscure: _obscure,
                  controller: _passwordCtrl,
                  validator: (v) => (v == null || v.isEmpty) ? 'Required' : null,
                  suffix: IconButton(
                    icon: Icon(_obscure
                        ? Icons.visibility_off_rounded
                        : Icons.visibility_rounded),
                    onPressed: () => setState(() => _obscure = !_obscure),
                  ),
                ),
                AppSpacing.vGapSm,
                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton(
                    onPressed: () => _showForgotSheet(context),
                    child: const Text('Forgot password?'),
                  ),
                ),
                AppSpacing.vGapLg,
                ElevatedButton(
                  onPressed: _loading ? null : _submit,
                  child: _loading
                      ? const SizedBox(
                          height: 22, width: 22,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : const Text('Sign In'),
                ),
                AppSpacing.vGapXxl,
                Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("Don't have an account? ", style: text.bodyMedium),
                      GestureDetector(
                        onTap: () => context.push('/register'),
                        child: Text('Sign Up',
                            style: text.labelLarge?.copyWith(color: AppColors.primary)),
                      ),
                    ],
                  ),
                ),
              ].animate(interval: 60.ms).fadeIn(duration: 350.ms).slideY(begin: 0.1, end: 0),
            ),
          ),
        ),
      ),
    );
  }

  void _showForgotSheet(BuildContext context) {
    final emailCtrl = TextEditingController();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
          left: AppSpacing.xl,
          right: AppSpacing.xl,
          top: AppSpacing.xl,
          bottom: MediaQuery.of(ctx).viewInsets.bottom + AppSpacing.xl,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Forgot password', style: Theme.of(ctx).textTheme.titleLarge),
            const SizedBox(height: 6),
            Text('Enter your email and we will send a temporary password to it. '
                'Sign in with that, then change it from Settings.',
                style: Theme.of(ctx).textTheme.bodyMedium),
            AppSpacing.vGapXl,
            AppTextField(
              label: 'Email',
              hint: 'you@example.com',
              icon: Icons.mail_outline_rounded,
              keyboardType: TextInputType.emailAddress,
              controller: emailCtrl,
            ),
            AppSpacing.vGapLg,
            ElevatedButton(
              onPressed: () async {
                final email = emailCtrl.text.trim();
                if (email.isEmpty) return;
                Navigator.pop(ctx);
                try {
                  await ref.read(dioProvider).post('/auth/forgot-password/', data: {'email': email});
                } catch (_) {}
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                        content: Text('If that account exists, a temporary password was emailed.')),
                  );
                }
              },
              child: const Text('Send temporary password'),
            ),
          ],
        ),
      ),
    );
  }
}
