import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/network/token_store.dart';
import '../../data/models/app_user.dart';
import '../../data/repositories/auth_repository.dart';

enum AuthStatus { unknown, authenticated, unauthenticated }

class AuthState {
  final AuthStatus status;
  final AppUser? user;
  const AuthState(this.status, [this.user]);
}

/// Owns the app's authentication state and actions.
class AuthController extends Notifier<AuthState> {
  @override
  AuthState build() {
    _restore();
    return const AuthState(AuthStatus.unknown);
  }

  AuthRepository get _repo => ref.read(authRepositoryProvider);

  Future<void> _restore() async {
    if (await TokenStore.instance.hasToken) {
      try {
        final user = await _repo.me();
        state = AuthState(AuthStatus.authenticated, user);
        return;
      } catch (_) {
        await TokenStore.instance.clear();
      }
    }
    state = const AuthState(AuthStatus.unauthenticated);
  }

  Future<void> login(String email, String password) async {
    final user = await _repo.login(email, password);
    state = AuthState(AuthStatus.authenticated, user);
  }

  Future<void> register(String username, String email, String password) async {
    final user = await _repo.register(username: username, email: email, password: password);
    state = AuthState(AuthStatus.authenticated, user);
  }

  Future<void> googleLogin() async {
    final user = await _repo.googleLogin();
    state = AuthState(AuthStatus.authenticated, user);
  }

  Future<void> logout() async {
    await _repo.logout();
    state = const AuthState(AuthStatus.unauthenticated);
  }
}

final authControllerProvider =
    NotifierProvider<AuthController, AuthState>(AuthController.new);
