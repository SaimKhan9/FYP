import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/network/api_client.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../data/repositories/hydration_repository.dart';

const _waterBlue = Color(0xFF3AA0FF);

class HydrationScreen extends ConsumerWidget {
  const HydrationScreen({super.key});

  Future<void> _log(WidgetRef ref, {int delta = 1}) async {
    await ref.read(hydrationRepositoryProvider).log(delta: delta);
    ref.invalidate(hydrationTodayProvider);
    ref.invalidate(hydrationHistoryProvider);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final text = Theme.of(context).textTheme;
    final todayAsync = ref.watch(hydrationTodayProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Hydration')),
      body: todayAsync.when(
        loading: () =>
            const Center(child: CircularProgressIndicator(color: _waterBlue)),
        error: (e, _) => Center(
          child: Padding(
            padding: const EdgeInsets.all(AppSpacing.xl),
            child: Text(describeApiError(e), textAlign: TextAlign.center),
          ),
        ),
        data: (today) {
          final goal = today.goal <= 0 ? 8 : today.goal;
          final glasses = today.glasses;
          final progress = (glasses / goal).clamp(0.0, 1.0);
          final ml = glasses * 250;

          return SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(
              AppSpacing.lg,
              AppSpacing.lg,
              AppSpacing.lg,
              AppSpacing.xxxl,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _ProgressRing(
                  progress: progress,
                  glasses: glasses,
                  goal: goal,
                  milliliters: ml,
                ),
                const SizedBox(height: AppSpacing.xl),
                _LogActions(
                  glasses: glasses,
                  onLog: (delta) => _log(ref, delta: delta),
                ),
                const SizedBox(height: AppSpacing.xl),
                Text(
                  'REMINDERS',
                  style: text.labelSmall?.copyWith(
                    color: AppColors.textSecondary,
                  ),
                ),
                const SizedBox(height: AppSpacing.sm),
                const _ReminderSettings(),
                const SizedBox(height: AppSpacing.xl),
                Text(
                  'LAST 7 DAYS',
                  style: text.labelSmall?.copyWith(
                    color: AppColors.textSecondary,
                  ),
                ),
                const SizedBox(height: AppSpacing.md),
                _ChartPanel(goal: goal),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _ProgressRing extends StatelessWidget {
  final double progress;
  final int glasses;
  final int goal;
  final int milliliters;

  const _ProgressRing({
    required this.progress,
    required this.glasses,
    required this.goal,
    required this.milliliters,
  });

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return LayoutBuilder(
      builder: (context, constraints) {
        final size = constraints.maxWidth.clamp(180.0, 220.0);
        return Center(
          child: SizedBox.square(
            dimension: size,
            child: Stack(
              alignment: Alignment.center,
              children: [
                SizedBox.square(
                  dimension: size,
                  child: TweenAnimationBuilder<double>(
                    tween: Tween(begin: 0, end: progress),
                    duration: const Duration(milliseconds: 600),
                    curve: Curves.easeOutCubic,
                    builder: (context, value, _) => CircularProgressIndicator(
                      value: value,
                      strokeWidth: 16,
                      strokeCap: StrokeCap.round,
                      backgroundColor: _waterBlue.withValues(alpha: 0.12),
                      valueColor: const AlwaysStoppedAnimation(_waterBlue),
                    ),
                  ),
                ),
                Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.water_drop_rounded,
                      color: _waterBlue,
                      size: 36,
                    ),
                    const SizedBox(height: AppSpacing.sm),
                    Text('$glasses / $goal', style: text.displaySmall),
                    Text('glasses - ${milliliters}ml', style: text.bodyMedium),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _LogActions extends StatelessWidget {
  final int glasses;
  final ValueChanged<int> onLog;

  const _LogActions({required this.glasses, required this.onLog});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final compact = constraints.maxWidth < 360;
        if (compact) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              FilledButton.icon(
                onPressed: () => onLog(1),
                style: FilledButton.styleFrom(
                  backgroundColor: _waterBlue,
                  minimumSize: const Size.fromHeight(56),
                ),
                icon: const Icon(Icons.add_rounded),
                label: const Text('Add a glass'),
              ),
              const SizedBox(height: AppSpacing.sm),
              OutlinedButton.icon(
                onPressed: glasses > 0 ? () => onLog(-1) : null,
                icon: const Icon(Icons.remove_rounded),
                label: const Text('Remove'),
              ),
            ],
          );
        }

        return Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: glasses > 0 ? () => onLog(-1) : null,
                icon: const Icon(Icons.remove_rounded),
                label: const Text('Remove'),
              ),
            ),
            const SizedBox(width: AppSpacing.md),
            Expanded(
              flex: 2,
              child: FilledButton.icon(
                onPressed: () => onLog(1),
                style: FilledButton.styleFrom(
                  backgroundColor: _waterBlue,
                  minimumSize: const Size.fromHeight(56),
                ),
                icon: const Icon(Icons.add_rounded),
                label: const Text('Add a glass'),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _ChartPanel extends StatelessWidget {
  final int goal;
  const _ChartPanel({required this.goal});

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(
          AppSpacing.md,
          AppSpacing.lg,
          AppSpacing.md,
          AppSpacing.md,
        ),
        child: _HistoryChart(goal: goal),
      ),
    );
  }
}

class _HistoryChart extends ConsumerWidget {
  final int goal;
  const _HistoryChart({required this.goal});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(hydrationHistoryProvider);
    return SizedBox(
      height: 170,
      child: async.when(
        loading: () =>
            const Center(child: CircularProgressIndicator(color: _waterBlue)),
        error: (_, _) => const SizedBox.shrink(),
        data: (series) => BarChart(
          BarChartData(
            maxY: (goal + 2).toDouble(),
            barTouchData: BarTouchData(enabled: false),
            borderData: FlBorderData(show: false),
            gridData: const FlGridData(show: false),
            titlesData: FlTitlesData(
              leftTitles: const AxisTitles(
                sideTitles: SideTitles(showTitles: false),
              ),
              topTitles: const AxisTitles(
                sideTitles: SideTitles(showTitles: false),
              ),
              rightTitles: const AxisTitles(
                sideTitles: SideTitles(showTitles: false),
              ),
              bottomTitles: AxisTitles(
                sideTitles: SideTitles(
                  reservedSize: 28,
                  showTitles: true,
                  getTitlesWidget: (value, _) {
                    final i = value.toInt();
                    if (i < 0 || i >= series.length) {
                      return const SizedBox.shrink();
                    }
                    final day = DateTime.parse(series[i].key);
                    return Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: Text(
                        ['M', 'T', 'W', 'T', 'F', 'S', 'S'][day.weekday - 1],
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    );
                  },
                ),
              ),
            ),
            barGroups: [
              for (var i = 0; i < series.length; i++)
                BarChartGroupData(
                  x: i,
                  barRods: [
                    BarChartRodData(
                      toY: series[i].value.toDouble(),
                      width: 16,
                      borderRadius: BorderRadius.circular(4),
                      color: i == series.length - 1
                          ? _waterBlue
                          : _waterBlue.withValues(alpha: 0.35),
                    ),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ReminderSettings extends ConsumerWidget {
  const _ReminderSettings();

  Future<void> _save(WidgetRef ref, Map<String, dynamic> patch) async {
    await ref.read(hydrationRepositoryProvider).updateSettings(patch);
    ref.invalidate(hydrationSettingsProvider);
    ref.invalidate(hydrationTodayProvider);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final text = Theme.of(context).textTheme;
    final async = ref.watch(hydrationSettingsProvider);
    return async.when(
      loading: () => const SizedBox(
        height: 72,
        child: Center(child: CircularProgressIndicator(color: _waterBlue)),
      ),
      error: (_, _) => const SizedBox.shrink(),
      data: (s) {
        final enabled = s['reminder_enabled'] == true;
        final hours = (s['interval_hours'] ?? 1) as int;
        final minutes = (s['interval_minutes'] ?? 0) as int;
        final totalMinutes = hours * 60 + minutes;
        final goal = (s['goal_glasses'] ?? 8) as int;
        final quietStart = _parseTime('${s['quiet_start'] ?? '22:00'}');
        final quietEnd = _parseTime('${s['quiet_end'] ?? '07:00'}');
        final quietOff = quietStart == quietEnd;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _SettingsTile(
              icon: Icons.flag_rounded,
              title: 'Daily goal',
              subtitle: '$goal glasses (${goal * 250} ml)',
              trailing: _StepperControl(
                value: goal,
                onDecrease: goal > 1
                    ? () => _save(ref, {'goal_glasses': goal - 1})
                    : null,
                onIncrease: goal < 20
                    ? () => _save(ref, {'goal_glasses': goal + 1})
                    : null,
              ),
            ),
            const SizedBox(height: AppSpacing.sm),
            _IntervalTile(
              totalMinutes: totalMinutes,
              onSelect: (m) => _save(ref, {
                'interval_hours': m ~/ 60,
                'interval_minutes': m % 60,
              }),
            ),
            const SizedBox(height: AppSpacing.sm),
            _SettingsTile(
              icon: Icons.bedtime_rounded,
              title: 'Quiet hours',
              subtitle: quietOff
                  ? 'Off (reminders any time)'
                  : 'No reminders ${quietStart.format(context)} - ${quietEnd.format(context)}',
              trailing: Wrap(
                spacing: AppSpacing.xs,
                runSpacing: AppSpacing.xs,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  if (!quietOff)
                    IconButton(
                      tooltip: 'Turn off quiet hours',
                      onPressed: () => _save(ref, {
                        'quiet_start': '00:00',
                        'quiet_end': '00:00',
                      }),
                      icon: const Icon(Icons.close_rounded, size: 18),
                      color: AppColors.textTertiary,
                      visualDensity: VisualDensity.compact,
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
                    ),
                  OutlinedButton(
                    onPressed: () =>
                        _pickQuiet(context, ref, quietStart, quietEnd),
                    child: Text(quietOff ? 'Set' : 'Edit'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: AppSpacing.sm),
            _SettingsTile(
              icon: Icons.notifications_active_rounded,
              title: 'Reminders',
              subtitle: enabled
                  ? 'On - every ${_fmtInterval(totalMinutes)}'
                  : 'Off',
              trailing: Switch(
                value: enabled,
                activeThumbColor: _waterBlue,
                onChanged: (v) => _save(ref, {'reminder_enabled': v}),
              ),
            ),
            const SizedBox(height: AppSpacing.sm),
            Text(
              'Reminders are delivered by the server and pause during quiet hours.',
              style: text.bodySmall?.copyWith(color: AppColors.textTertiary),
            ),
          ],
        );
      },
    );
  }

  static String _fmtInterval(int minutes) {
    if (minutes < 60) return '${minutes}m';
    final h = minutes ~/ 60;
    final m = minutes % 60;
    return m == 0 ? '${h}h' : '${h}h ${m}m';
  }

  static TimeOfDay _parseTime(String s) {
    final parts = s.split(':');
    return TimeOfDay(
      hour: int.tryParse(parts.isNotEmpty ? parts[0] : '') ?? 0,
      minute: int.tryParse(parts.length > 1 ? parts[1] : '') ?? 0,
    );
  }

  static String _hhmm(TimeOfDay t) =>
      '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';

  Future<void> _pickQuiet(
    BuildContext context,
    WidgetRef ref,
    TimeOfDay start,
    TimeOfDay end,
  ) async {
    final newStart = await showTimePicker(
      context: context,
      initialTime: start,
      helpText: 'Quiet hours START (no reminders after)',
    );
    if (newStart == null || !context.mounted) return;
    final newEnd = await showTimePicker(
      context: context,
      initialTime: end,
      helpText: 'Quiet hours END (reminders resume)',
    );
    if (newEnd == null) return;
    await _save(ref, {
      'quiet_start': _hhmm(newStart),
      'quiet_end': _hhmm(newEnd),
    });
  }
}

class _IntervalTile extends StatelessWidget {
  final int totalMinutes;
  final ValueChanged<int> onSelect;

  const _IntervalTile({required this.totalMinutes, required this.onSelect});

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return Container(
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: _tileDecoration(context),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const _LeadingIcon(Icons.timer_rounded),
              const SizedBox(width: AppSpacing.md),
              Expanded(child: Text('Remind me every', style: text.titleSmall)),
            ],
          ),
          const SizedBox(height: AppSpacing.sm),
          Wrap(
            spacing: AppSpacing.sm,
            runSpacing: AppSpacing.sm,
            children: [1, 5, 15, 30, 45, 60, 120, 180, 240].map((m) {
              final selected = m == totalMinutes;
              return ChoiceChip(
                label: Text(_ReminderSettings._fmtInterval(m)),
                selected: selected,
                onSelected: (_) => onSelect(m),
                selectedColor: _waterBlue,
                labelStyle: text.labelMedium?.copyWith(
                  color: selected ? Colors.white : AppColors.textSecondary,
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}

class _SettingsTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Widget trailing;

  const _SettingsTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return Container(
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: _tileDecoration(context),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _LeadingIcon(icon),
              const SizedBox(width: AppSpacing.md),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: text.titleSmall),
                    const SizedBox(height: AppSpacing.sm),
                    Text(subtitle, style: text.bodySmall),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.sm),
          Align(
            alignment: Alignment.centerRight,
            child: trailing,
          ),
        ],
      ),
    );
  }
}

class _StepperControl extends StatelessWidget {
  final int value;
  final VoidCallback? onDecrease;
  final VoidCallback? onIncrease;

  const _StepperControl({
    required this.value,
    required this.onDecrease,
    required this.onIncrease,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        _StepperButton(icon: Icons.remove_rounded, onTap: onDecrease),
        SizedBox(
          width: 28,
          child: Text(
            '$value',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.titleMedium,
          ),
        ),
        _StepperButton(icon: Icons.add_rounded, onTap: onIncrease),
      ],
    );
  }
}

class _LeadingIcon extends StatelessWidget {
  final IconData icon;
  const _LeadingIcon(this.icon);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 40,
      height: 40,
      decoration: BoxDecoration(
        color: _waterBlue.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Icon(icon, color: _waterBlue, size: 20),
    );
  }
}

BoxDecoration _tileDecoration(BuildContext context) => BoxDecoration(
  color: Theme.of(context).colorScheme.surface,
  borderRadius: BorderRadius.circular(12),
);

class _StepperButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onTap;
  const _StepperButton({required this.icon, this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: onTap == null 
              ? Colors.transparent 
              : _waterBlue.withValues(alpha: 0.1),
        ),
        child: Icon(
          icon,
          size: 20,
          color: onTap == null ? AppColors.textTertiary : _waterBlue,
        ),
      ),
    );
  }
}