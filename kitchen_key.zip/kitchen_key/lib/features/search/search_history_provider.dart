import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../data/models/recipe.dart';
import '../../data/repositories/recipe_repository.dart';

/// Remembers the user's recent search terms (most-recent first, deduped, capped)
/// and persists them so recommendations survive app restarts.
class SearchHistoryNotifier extends Notifier<List<String>> {
  static const _key = 'search_history_v1';
  static const _max = 12;

  @override
  List<String> build() {
    _load();
    return const [];
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final list = prefs.getStringList(_key) ?? const [];
    if (list.isNotEmpty) state = list;
  }

  Future<void> record(String query) async {
    final q = query.trim();
    if (q.length < 2) return;
    final next = [q, ...state.where((e) => e.toLowerCase() != q.toLowerCase())]
        .take(_max)
        .toList();
    state = next;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_key, next);
  }

  Future<void> clear() async {
    state = const [];
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
  }
}

final searchHistoryProvider =
    NotifierProvider<SearchHistoryNotifier, List<String>>(SearchHistoryNotifier.new);

/// "Recommended for you" — recipes derived from the user's recent searches.
/// Pulls a few results for each of the latest search terms, deduped by id.
final searchRecommendationsProvider = FutureProvider.autoDispose<List<Recipe>>((ref) async {
  final history = ref.watch(searchHistoryProvider);
  if (history.isEmpty) return const [];

  final repo = ref.watch(recipeRepositoryProvider);
  final seen = <String>{};
  final out = <Recipe>[];
  for (final term in history.take(3)) {
    try {
      final results = await repo.getRecipes(RecipeQuery(search: term, limit: 8));
      for (final r in results) {
        if (seen.add(r.id)) out.add(r);
        if (out.length >= 12) return out;
      }
    } catch (_) {
      // ignore a failed term; keep whatever we have
    }
  }
  return out;
});
