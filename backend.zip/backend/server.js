const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const userRoute = require("./routes/user");

const app = express();

app.use(express.json());
app.use(cors());

// DB Connection
mongoose.connect("mongodb://127.0.0.1:27017/flutterapp")
  .then(() => console.log("MongoDB Connected"))
  .catch(err => console.log(err));

// Routes
app.use("/auth", userRoute);

// Server start
app.listen(5000, () => {
  console.log("Server running on port 5000");
});
