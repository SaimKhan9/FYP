const User = require('../models/user');
const bcrypt = require("bcrypt");

async function handleUserSignup(req, res) {
    const { name, email, password } = req.body;

    const hashedPass = await bcrypt.hash(password, 10);

    await User.create({
        name,
        email,
        password: hashedPass,
    });

    return res.json({ message: "User created successfully" });
}

module.exports = {
    handleUserSignup,
};
